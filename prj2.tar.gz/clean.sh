#!/bin/bash

rm -rf IndexDump
rm -rf IndexFiles
rm -rf TextFiles