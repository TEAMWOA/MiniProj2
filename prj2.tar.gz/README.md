# MiniProj2
Indexing, Hashing and Sorting of Ads

## Script Version 
Automatically parses the XML file, creates, sorts and formats the .txt files and creates index files.

Instructions to run:
- Place XML file in XML folder
- Execute following commands:
    - chmod +x permissions.sh
    - ./permissions.sh
- Run the script file with the name of the XML file as an argument
    - ./script.sh 100k
- To delete the folders it creates, run the clean script
    - ./clean.sh